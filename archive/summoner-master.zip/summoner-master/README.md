# Summoner
Foundry VTT Summoner Module

Provides a simple compendium pack to help with DND5e spells that summon creatures. 

Created after my players complained they had problems moving npc tokens that I gave them control over. Since that didn't seem to work too well, I just made player actors and copied all the data from the NPCs.

Hope this saves some people some time from having to create all the actors.

Right now this supports the following spells:
* Find Familiar
* Unseen Servant

I'll add more as time goes on.
