# Summoner
This FoundryVTT Module adds a simple compendium pack to help with DnD5e spells that summon creatures.
It is nothing fancy. My players were casting find familiar and I tried to use the npc creatures that
are in the DnD5e system and it wasn't working.  So all I did was create actor/player types for each 
creature they could summon.

Hope this saves you some time.  

Right now this only supports the following spells:
* Find Familiar
* Unseen Servant

I'll add more as time goes on.

## Install
To install this module, go to the World Configuration and Setup, Addon Modules, Install Module.
Then you may copy this url https://raw.githubusercontent.com/Jonwh25/summoner/master/module.json

## Contributions
Every contribution is welcome.