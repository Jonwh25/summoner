# Change Log

All notable changes to this project will be documented in this file.

<!--
## [Unreleased]

### Added

### Changed

### Deprecated

### Removed

### Fixed

### Security
-->
## [v0.1.1] 2020-05-22
### Changed
* Updated module.json to be compatible with Release 0.6.0


## [v0.1.0] 2020-05-21
### Added
Initial Release for Summoner.  Created the Summoner Compendium and filled it with creatures for Find Familiar and Unseen Servant
* Bat
* Cat
* Crab
* Frog
* Hawk
* Lizard
* Octopus
* Owl
* Poisonous Snake
* Fish (Quipper)
* Rat
* Raven
* Sea Horse
* Spider
* Weasel
* Unseen Servant